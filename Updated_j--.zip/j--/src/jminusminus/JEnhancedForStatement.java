package jminusminus;

import java.util.*;//ArrayList;
import static jminusminus.CLConstants.*;

class JEnhancedForStatement extends JStatement {
	private Type init;
	private TypeName initS;//a quaifiedIdnetifier
	private TypeName iterator;
	private JStatement express;
	private String fin; //optional final
	//Collection<?> iterator;
	//ArrayList<String> test;
	
	public JEnhancedForStatement(int line, Type init, TypeName initS, TypeName iterator,
			JStatement express, String fin) {
		super(line);
		this.init = init;
		this.initS = initS;
		this.iterator = iterator;
		this.express = express;
		this.fin = fin;
	}
	
	public JStatement analyze(Context context) {
		return this;
	}
	
	public void codegen(CLEmitter output) {
		
	}
	
	public void writeToStdOut(PrettyPrinter p) {
		p.printf("<JEnhancedForStatement line=\"%d\">\n", line());
		if (fin != null){
        	p.indentRight();
	        p.printf("%s\n", fin);
	        p.indentLeft();
        }
		p.indentRight();
        p.printf("<Type>\n");
        if (init != null){
	        p.indentRight();
	        p.printf("%s\n", init.toString());//init.writeToStdOut(p);
	        p.indentLeft();
        }
	    p.printf("</Type>\n");
	    p.printf("<Identifier>\n");
        if (initS != null){
	        p.indentRight();
	        p.printf("%s\n", initS.toString());
	        p.indentLeft();
        }
        p.printf("</Identifier>\n");
        p.printf("<Iterator>\n");
        if (iterator != null){
	        p.indentRight();
	        p.printf("%s\n", iterator.toString());
	        p.indentLeft();
        }
        p.printf("</Iterator>\n");
        p.indentLeft();
        p.printf("<Express>\n");
        if (express != null){
	        p.indentRight();
	        express.writeToStdOut(p);
	        p.indentLeft();
        }
        p.printf("</express>\n");
        p.printf("</JEnhancedForStatement>\n");
	}
}