package jminusminus;

import java.util.ArrayList;
import static jminusminus.CLConstants.*;

class JForStatement extends JStatement {
	ArrayList<JVariableDeclarator> init;
	ArrayList<JStatement> initS;
	JExpression test;
	ArrayList<JStatement> update;
	JStatement express;
	/** Variable initializations. */
    private ArrayList<JStatement> initializations = new ArrayList<JStatement>();
    
    private LocalContext context2;
    
    PrettyPrinter p;
	
	public JForStatement(int line, ArrayList<JVariableDeclarator> init, ArrayList<JStatement> initS,
			JExpression test, ArrayList<JStatement> update,
							JStatement express) {
		super(line);
		this.init = init;
		this.initS = initS;
		this.test = test;
		this.update = update;
		this.express = express;
	}
	
	public JStatement analyze(Context context) {
		if (init != null) {//note that this is a Variable Declarator so,
			   this.context2 = new LocalContext(context);
			   //YOU NEED TO LOOK AT HOW METHOD CONTEXT IS BUILT
			   
			//   public JVariableDeclarator analyze(Context context) {
//			          // Not used. Analysis is done further up the tree.
//			          return this;
//			      }
			   for (JVariableDeclarator decl : init) {
			    LocalVariableDefn defn = new LocalVariableDefn(decl.type(), 
			                  this.context2.offset());
			          defn.initialize();
			          this.context2.addEntry(decl.line(), decl.name(), defn);
			    //System.out.println(decl);
			    //decl.writeToStdOut(p);
			    decl.setType(decl.type().resolve(this.context2));
			   //}
			    // All initializations must be turned into assignment
			             // statements and analyzed
//			    decl.initializer();
//			    System.out.println(decl.toString());
			             if (decl.initializer() != null) {
			                 JAssignOp assignOp = new JAssignOp(decl.line(), new JVariable(
			                         decl.line(), decl.name()), decl.initializer());
			                 assignOp.isStatementExpression = true;
			                 assignOp.analyze(this.context2);
//			                 LocalVariableDefn assignOp2 = (LocalVariableDefn) assignOp;
			                 //decl.analyze(context);
			                 //decl.writeToStdOut(p);
			                 initializations.add(
			                   new JStatementExpression(decl.line(), 
			                   assignOp).analyze(this.context2));
			             }
			   }
			  } else if (initS != null) {
			   for (int i = 0; i < initS.size(); i++) {
			    initS.set(i, (JStatement) initS.get(i).analyze(context));
			   }
			  }
			  if (test != null) {
			   if (init != null) {//defines the context of the test
			    test = test.analyze(this.context2);
			   } else {
			    test = test.analyze(context);
			   }
			         test.type().mustMatchExpected(line(), Type.BOOLEAN);
			  }
			  if (update != null){
			   if (init != null) {
			    for (int i = 0; i < update.size(); i ++) {
			     update.set(i, (JStatement) update.get(i).analyze(this.context2));
			    }
			   } else {
			    for (int i = 0; i < update.size(); i ++) {
			     update.set(i, (JStatement) update.get(i).analyze(context));
			    }
			   }
			  }
			  if (express != null) {
			   if (init != null) {
			    express = (JStatement) express.analyze(this.context2);
			   } else {
			    express = (JStatement) express.analyze(context);
			   }
			  }
		return this;
	}
	
	public void codegen(CLEmitter output) {
		  // Need two labels
		  //String initial = output.createLabel();
		  //execute the initializations
		//  if (init != null) {
		//   for (JVariableDeclarator decl : init) {
//		    decl.codgen(output);
//		    //codegen is empty for JVariableDeclarator
		//   }
		//  }
		  
		  if (initS != null) {
		   for (int i = 0; i < initS.size(); i++) {
		    initS.get(i).codegen(output);
		   }
		  } else if (init != null) {
		   for (int i = 0; i < initializations.size(); i++) {
		    initializations.get(i).codegen(output);
		   }
		  }
		  
		        String testLabel = output.createLabel();
		        String out = output.createLabel();

		        // Branch out of the loop on the test condition
		        // being false
		        //output.addLabel(initial);
		        output.addLabel(testLabel);
		        
		        if (test != null) {
		         test.codegen(output, out, false);
		        }
		        // Codegen body
		        if (express instanceof JBlock){
		        	JBlock express2 = (JBlock) express;
		        	for (JStatement statement : express2.statements()) {
		        		if (statement instanceof JBreakStatement) {
		        			output.addBranchInstruction(GOTO, out);
		        		} else {
		        			statement.codegen(output);
		        		}
		            }
		        } else {
		        	if (express instanceof JBreakStatement) {
		        		output.addBranchInstruction(GOTO, out);
		        	} else {
		        		express.codegen(output);
		        	}
		        	//express.codegen(output);
		        }
		        //update it
		        if (update != null) {
		         for (int i = 0; i < update.size(); i ++) {
		          update.get(i).codegen(output);
		         }
		        }

		        // Unconditional jump back up to test
		        output.addBranchInstruction(GOTO, testLabel);

		        // The label below and outside the loop
		        output.addLabel(out);
	}
	
	public void writeToStdOut(PrettyPrinter p) {
		p.printf("<JForStatement line=\"%d\">\n", line());
		p.indentRight();
        p.printf("<InitialValue>\n");
        if (init != null){
	        p.indentRight();
	        for (JVariableDeclarator s : init) {
	        	s.writeToStdOut(p);
	        }
	        p.indentLeft();
        } else if (initS != null){
	        p.indentRight();
	        for (JStatement s : initS) {
	        	s.writeToStdOut(p);
	        }
	        p.indentLeft();
        }
        p.printf("</InitialValue>\n");
        p.indentLeft();
        p.indentRight();
        p.printf("<Test>\n");
        if (test != null){
	        p.indentRight();
	        test.writeToStdOut(p);
	        p.indentLeft();
        }
        p.printf("</Test>\n");
        p.indentLeft();
        p.indentRight();
        p.printf("<Update>\n");
        if (update != null){
	        p.indentRight();
	        for (JStatement s : update) {
	        	s.writeToStdOut(p);
	        }
	        p.indentLeft();
        }
        p.printf("</Update>\n");
        p.indentLeft();
        p.printf("<Express>\n");
        if (express != null){
	        p.indentRight();
	        express.writeToStdOut(p);
	        p.indentLeft();
        }
        p.printf("</express>\n");
        p.printf("</JForStatement>\n");
	}
}