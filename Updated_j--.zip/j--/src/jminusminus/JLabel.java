//modification of JLabel by Bob Wilson

package jminusminus;

import static jminusminus.CLConstants.*;

import java.util.*;

/**
 * The AST node for a return-statement. If the enclosing method
 * in non-void, then there is a value to return, so we keep track
 * of the expression denoting that value and its type.
 */

class JLabel
    extends JStatement {

    
    private String expr;

    private Context labelContext;
    
    private String jvmLabel;
    
    private JStatement state;
    
    private ArrayList<JLabel> labs;
    /**
     * Construct an AST node for a return-statement given its
     * line number, and the expression that is returned.
     * 
     * @param line
     *                line in which the return-statement appears
     *                in the source file.
     * @param expr
     *                the returned expression.
     */

    public JLabel(int line, String expr, JStatement state, ArrayList<JLabel> labs) {
        super(line);
        this.state = state;
        this.expr = expr;
        this.labs = labs;
    }
    
    public String getLabel() {
    	return this.expr;
    }
    
    public String getJVMLabel() {
    	return jvmLabel;
    }

    /**
     * Analysis distinguishes between our being in a constructor
     * or in a regular method in checking return types. In the
     * case of a return expression, analyze it and check types.
     * Determine the (possibly void) return type.
     * 
     * @param context
     *                context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JStatement analyze(Context context) {
    	state = (JStatement) state.analyze(context);
        return this;
    }

    /**
     * Generate code for the return statement. In the case of
     * void method types, generate a simple (void) return. In the
     * case of a return expression, generate code to load that
     * onto the stack and then generate the appropriate return
     * instruction.
     * 
     * @param output
     *                the code emitter (basically an abstraction
     *                for producing the .class file).
     */

    public void codegen(CLEmitter output) {
    	jvmLabel = output.createLabel();
    	/* This is a special form of codegen that is called
    	 * for a loop (DoWhile, While, For) when a label is
    	 * used
    	 */
    	//state.codegen(output);
    	state.labelCodegen(output, jvmLabel, expr, labs);
    	output.addLabel(jvmLabel);
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
//        if (expr != null) {
            p.printf("<JLabel line=\"%d\">\n", line());
            p.indentRight();
            p.printf("%s\n", expr);
            //expr.writeToStdOut(p);
            state.writeToStdOut(p);
            p.indentLeft();
            p.printf("</JLabel>\n");
//        } else {
//            p.printf("<JBreakStatement line=\"%d\"/>\n", line());
//        }
    }
}
