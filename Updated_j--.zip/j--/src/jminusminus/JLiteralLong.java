//Modification of JLiteralInt by Bob Wilson
package jminusminus;

import static jminusminus.CLConstants.*;
/**
 * The AST node for an int literal.
 */

class JLiteralLong extends JExpression {

    /** String representation of the int. */
    private String text;

    /**
     * Construct an AST node for an int literal given its line number and string
     * representation.
     * 
     * @param line
     *            line in which the literal occurs in the source file.
     * @param text
     *            string representation of the literal.
     */

    public JLiteralLong(int line, String text) {
        super(line);
        this.text = text;
    }

    /**
     * Analyzing an int literal is trivial.
     * 
     * @param context
     *            context in which names are resolved (ignored here).
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JExpression analyze(Context context) {
        type = Type.LONG;
        return this;
    }

    /**
     * Generating code for an int literal means generating code to push it onto
     * the stack.
     * 
     * @param output
     *            the code emitter (basically an abstraction for producing the
     *            .class file).
     */

    public void codegen(CLEmitter output) {
    	//remove the trailing L
    	//text.replace(text.charAt(text.length() - 1), '');
    	text = text.substring(0, text.length() - 1 );
    	//System.out.println("in codgen " + text);
        long i = Long.parseLong(text);
        //output.addLDCInstruction(i);
        //System.out.println("in codgen " + i);
        //switch (i) {
        if ( i == 0L) {
            output.addNoArgInstruction(LCONST_0);
        }
        else if ( i == 1L) {
            output.addNoArgInstruction(LCONST_1);
        }
//        else if ((int) i == 2) {//no such thing as LCont2
//            output.addNoArgInstruction(LCONST_2);
//        }
//        else if ((int) i == 3) {
//            output.addNoArgInstruction(ICONST_3);
//        }
//        else if ((int) i == 4) {
//            output.addNoArgInstruction(ICONST_4);
//        }
//        else if ((int) i == 5) {
//            output.addNoArgInstruction(ICONST_5);
//        }
//        else {
//            if ((int) i >= 0 && (int) i <= 127) {
//                output.addOneArgInstruction(BIPUSH, (int) i);
//            } else if ((int) i >= 128 && (int) i <= 32767) {
//                output.addOneArgInstruction(SIPUSH, (int) i);
//            } else if ((int) i >= 32768 && (int) i <=  2147483647 ){//it can fit into an int
//                output.addLDCInstruction((int) i);
//            } 
            else {//it has to be a long 
            	output.addLDCInstruction(i);
            }//see CLEMiitter line 1756 	
//        }
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JLiteralLong line=\"%d\" type=\"%s\" " + "value=\"%s\"/>\n",
                line(), ((type == null) ? "" : type.toString()), text);
    }

}
