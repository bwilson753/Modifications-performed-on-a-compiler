//modification of JReturnStatement by Bob Wilson

package jminusminus;

import static jminusminus.CLConstants.*;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.TreeMap;

/**
 * The AST node for a return-statement. If the enclosing method
 * in non-void, then there is a value to return, so we keep track
 * of the expression denoting that value and its type.
 */

class JSwitchStatement
    extends JStatement {

    
	//private ArrayList<HashMap<ArrayList<JExpression>, ArrayList<JStatement>>> sws;
	private ArrayList<JExpression> sws;//holds case and default
	private ArrayList<ArrayList<JStatement>> sws3;//holds expressions
	private JExpression expr;//holds the main switch case

    /**
     * Construct an AST node for a return-statement given its
     * line number, and the expression that is returned.
     * 
     * @param line
     *                line in which the return-statement appears
     *                in the source file.
     * @param expr
     *                the returned expression.
     */

    public JSwitchStatement(int line, JExpression expr, ArrayList<JExpression> sws, 
    		ArrayList<ArrayList<JStatement>> sws3) {
    		//ArrayList<HashMap<ArrayList<JExpression>, ArrayList<JStatement>>> sws) {
        super(line);
        this.expr = expr;
        this.sws = sws;
        this.sws3 = sws3;
    }

    /**
     * Analysis distinguishes between our being in a constructor
     * or in a regular method in checking return types. In the
     * case of a return expression, analyze it and check types.
     * Determine the (possibly void) return type.
     * 
     * @param context
     *                context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JStatement analyze(Context context) {
    	JExpression f = (JExpression) expr.analyze(context);
    	
    	for (JExpression a : sws) {
    		if (a != null) {
	    		a = (JExpression) a.analyze(context);
	    		if (a.type() == Type.CHAR){
	    			a.type().mustMatchExpected(line(), Type.CHAR);
	    		} else {
	    			a.type().mustMatchExpected(line(), Type.INT);
	    		}
    		}
    	}
    	for (ArrayList<JStatement> b : sws3) {
    		if (b != null) {
	    		for (JStatement c : b) {
	    			if (c != null) {
			    		c.analyze(context);
			    		c = (JStatement) c.analyze(context);
	    			}
	    		}
    		}
    	}
//    	condition = (JExpression) condition.analyze(context);
//        condition.type().mustMatchExpected(line(), Type.BOOLEAN);
//        thenPart = (JStatement) thenPart.analyze(context);
//        if (elsePart != null) {
//            elsePart = (JStatement) elsePart.analyze(context);
//        }
        return this;
    }

    /**
     * Generate code for the return statement. In the case of
     * void method types, generate a simple (void) return. In the
     * case of a return expression, generate code to load that
     * onto the stack and then generate the appropriate return
     * instruction.
     * 
     * @param output
     *                the code emitter (basically an abstraction
     *                for producing the .class file).
     */

    public void codegen(CLEmitter output) {
    	//from CLEmitter
    	/**
         * Add a TABLESWITCH instruction -- used for switch statements.
         * 
         * @param defaultLabel
         *            jump label for default value.
         * @param low
         *            smallest value of index.
         * @param high
         *            highest value of index.
         * @param labels
         *            list of jump labels for each index value from low to high, end
         *            values included.
         */
//    	output.addTABLESWITCHInstruction(String defaultLabel, int low,
//                int high, ArrayList<String> labels) {
//    	private ArrayList<JExpression> sws;//holds case and default
//    	private ArrayList<ArrayList<JStatement>> sws3;//holds expressions
    	
//    	System.out.println(sws.get(0));
//    	JLiteralChar foo =  (JLiteralChar) sws.get(0);
//    	System.out.println(foo.getLiteral());
    	
    	//the results of this will go in int low arg
    	int lowest = 9;
    	int highest = 0;
    	boolean isInt = false;
    	char lowestC = '9';
    	char highestC = '0';
    	boolean isChar = false;
    	String lowestS = "0";
    	boolean isString = false;
    	for (JExpression s : sws) {
    		if (s != null) {
	    		if (s.type() == Type.CHAR) {
	    			JLiteralChar foo =  (JLiteralChar) s;
	    			if (!isChar) {
	    				lowestC = foo.getLiteral();
	    				highestC = foo.getLiteral();
	    				isChar = true;
	    			}
	    			else if (foo.getLiteral() < lowestC) {
	    				lowestC = foo.getLiteral();
	    			}
	    			else if (foo.getLiteral() > highestC) {
	    				highestC = foo.getLiteral();
	    			}
	    		} else { //if (s.type() == Type.INT){ //it is an int
	    			JLiteralInt foo =  (JLiteralInt) s;
	    			if (!isInt) {
	    				lowest = foo.getLiteral();
	    				highest = foo.getLiteral();
	    				isInt = true;
	    			}
	    			else if (foo.getLiteral() < lowest) {
	    				lowest = foo.getLiteral();
	    			}
	    			else if (foo.getLiteral() > highest) {
	    				highest = foo.getLiteral();
	    			}
	    		} 
    		}
    	}
    		
		ArrayList<String> labels = new ArrayList<String>();
		TreeMap<Integer, String> labels2 = new TreeMap<Integer, String>();
		int g = 1;
		for (JExpression so : sws) {
    		if (so != null) {
    			if (so.type() == Type.CHAR) {
	    			JLiteralChar fooC =  (JLiteralChar) so;
	    			labels.add(output.createLabel());
	    			int conv =  (int) fooC.getLiteral();
	    			labels2.put(conv, labels.get(g - 1));
	    			//labels.add(Integer.toString(g));//foo.getLiteral()));
    			} else {
    				JLiteralInt foo =  (JLiteralInt) so;
	    			//labels.add(Integer.toString(g));//foo.getLiteral()));
	    			//System.out.println("wrote " + g);
	    			JLiteralInt soI = (JLiteralInt) so;
	    			//System.out.println(soI.getLiteral());
	    			labels.add(output.createLabel());
	    			labels2.put(soI.getLiteral(), labels.get(g - 1));
    			}
    		}
    		g++;
		}
		
		//add default
		labels.add(output.createLabel());
		g--;//default is one two high
		//labels2.put(g, Integer.toString(g));
		
		expr.codegen(output);//the main expression next to switch
		//System.out.println("outside booleans");
		if (isInt && isChar) {//uses a mix of ints and chars
			//j-- doesn't currenlty support a mix, but this could be used for future updates
    		if (lowestC < lowest) {
    			lowest = lowestC;
    		}
    		if (highestC > highest) {
    			highest = highestC;
    		}
    		//System.out.println("inside if");
    		//output.addTABLESWITCHInstruction(labels.get(g - 1), lowest, highest, labels);
    		output.addLOOKUPSWITCHInstruction(labels.get(g - 1), labels2.size(), labels2);
    	}
		else if (isInt && !isChar) {//just ints
			//System.out.println(Integer.toString(g));
			//output.addTABLESWITCHInstruction(Integer.toString(g), lowest, highest, labels);
			output.addLOOKUPSWITCHInstruction(labels.get(g - 1), labels2.size(), labels2);
		} else {
//			ArrayList<String> labels2 = new ArrayList<String>();
//			labels2.add("1");
//			labels2.add("2");
//			labels2.add("3");
//			//labels2.add("default");
//			for(ArrayList<JStatement> a : sws3) {
//				for (JStatement b : a)
//					labels2.add(b.context().offset());
//			}
			//System.out.println("inside else");
			output.addLOOKUPSWITCHInstruction(labels.get(g - 1), labels2.size(), labels2);
			//output.addTABLESWITCHInstruction(Integer.toString(g), lowestC, highestC, labels);
		}
			
		int f = 0;
		boolean hasBreak = false;
		String done = output.createLabel();
		for(ArrayList<JStatement> a : sws3) {
			output.addLabel(labels.get(f++));
			for (JStatement b : a){
				//output.addLabel(labels.get(f++));//(Integer.toString(f++));
				if (b instanceof JBreakStatement) {
					//done = output.createLabel();
					output.addBranchInstruction(GOTO, done);
					hasBreak = true;
				} else {
					b.codegen(output);
				}
				//System.out.println("writing " + f);
				//f++;
			}
		}
		if (hasBreak){
			output.addLabel(done);
		}
		
		//output.addLabel("done");
    		
		//System.out.println(labels.toString());
    		//Can't use String in j--
//    		else { //it is aString
//    			JLiteralString foo =  (JLiteralString) s;
//    			if (!isString) {
//    				lowestS = foo.getLiteral();
//    				isString = true;
//    			}
//    			else if (foo.getLiteral().compareTo(lowestS) < 0) {
//    				lowestS = foo.getLiteral();
//    			}
//    		}
    	
    	
    	//TESTS
//    	System.out.println(lowestC);
//    	System.out.println(lowest);
//    	System.out.println(highestC);
//    	System.out.println(highest);
//    	System.out.println();
    	//output.addTABLESWITCHInstruction("default", 
    	//it appears that it only builds the table.  The actual instructions also 
    	//still need to be written

    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
    	p.printf("<JSwitchStatement line=\"%d\">\n", line());
    	p.indentRight();
    	int i = 0;
    	//add main expression
    	expr.writeToStdOut(p);
        for (JExpression s : sws) {
        	if (s != null) {
	        	p.printf("<Case>");
	        	s.writeToStdOut(p);
        	} else {
        		p.printf("<Default>\n");
        	}
        	if (sws3.get(i) != null){
        		for (JStatement t : sws3.get(i)) {
        			if (t != null) {
        				t.writeToStdOut(p);
        			}
        		}
        	}
        	i++;
        }
        
        p.indentLeft();
    	p.printf("</JSwitchStatement line=\"%d\">\n", line());
//        if (expr != null) {
//            p.printf("<JBreakStatement line=\"%d\">\n", line());
//            p.indentRight();
//            p.printf("%s\n", expr);
//            //expr.writeToStdOut(p);
//            p.indentLeft();
//            p.printf("</JBreakStatement>\n");
//        } else {
//            p.printf("<JBreakStatement line=\"%d\"/>\n", line());
//        }
    }
}
