package jminusminus;

import java.util.ArrayList;
import static jminusminus.CLConstants.*;

class JTryStatement extends JStatement {
	JBlock tryBlock;
	ArrayList<JFormalParameter> parameters;
	ArrayList<JBlock> catchBlock;
	JBlock finallyBlock;
	
	public JTryStatement(int line, JBlock tryBlock, ArrayList<JFormalParameter> parameters,
							ArrayList<JBlock> catchBlock, JBlock finallyBlock) {
		super(line);
		this.tryBlock = tryBlock;
		this.parameters = parameters;
		this.catchBlock = catchBlock;
		this.finallyBlock = finallyBlock;
	}
	
	public JStatement analyze(Context context) {
		return this;
	}
	
	public void codegen(CLEmitter output) {
		
	}
	
	public void writeToStdOut(PrettyPrinter p) {
		p.printf("<JTryStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<TryBlock>\n");
        p.indentRight();
        tryBlock.writeToStdOut(p);
        p.indentLeft();
        p.printf("</TryBlock>\n");
        if (!parameters.isEmpty()){
	        p.printf("<CatchBlock>\n");
	        p.indentRight();
	        if (!parameters.isEmpty()) {
		        p.printf("<CatchParameters>\n");
		        for (JFormalParameter member : parameters) {
	                ((JAST) member).writeToStdOut(p);
	            }
		        p.printf("</CatchParemeters>\n");
	        }
	        int i = 1;
	        for (JBlock member : catchBlock) {
	        	p.printf("<CatchBlock %d>\n", i);
	            ((JAST) member).writeToStdOut(p);
	            p.printf("</CatchBlock %d>\n", i);
	            i++;
	        }
	        p.indentLeft();
	        p.printf("</CatchBlock>\n");
        }
        if (finallyBlock != null) {
            p.printf("<FinallyBlock>\n");
            p.indentRight();
            finallyBlock.writeToStdOut(p);
            p.indentLeft();
            p.printf("</FinallyBlock>\n");
        }
        p.indentLeft();
        p.printf("</JTryStatement>\n");
	}
}