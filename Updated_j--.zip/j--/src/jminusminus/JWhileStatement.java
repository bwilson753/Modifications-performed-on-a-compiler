// Copyright 2013 Bill Campbell, Swami Iyer and Bahar Akbal-Delibas

package jminusminus;

import static jminusminus.CLConstants.*;

import java.util.*;
/**
 * The AST node for a while-statement.
 */

class JWhileStatement extends JStatement {

    /** Test expression. */
    private JExpression condition;

    /** The body. */
    private JStatement body;
    
    //for labels
    private String jvmLabel2;
    private String label2;
    private ArrayList<JLabel> labs2;
    private boolean hasLabel = false;

    /**
     * Construct an AST node for a while-statement given its line number, the
     * test expression, and the body.
     * 
     * @param line
     *            line in which the while-statement occurs in the source file.
     * @param condition
     *            test expression.
     * @param body
     *            the body.
     */

    public JWhileStatement(int line, JExpression condition, JStatement body, ArrayList<JLabel> labs2) {
        super(line);
        this.condition = condition;
        this.body = body;
        this.labs2 = labs2;
    }

    /**
     * Analysis involves analyzing the test, checking its type and analyzing the
     * body statement.
     * 
     * @param context
     *            context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */

    public JWhileStatement analyze(Context context) {
        condition = condition.analyze(context);
        condition.type().mustMatchExpected(line(), Type.BOOLEAN);
        body = (JStatement) body.analyze(context);
        return this;
    }

    /**
     * Generate code for the while loop.
     * 
     * @param output
     *            the code emitter (basically an abstraction for producing the
     *            .class file).
     */

    public void codegen(CLEmitter output) {
    	if (this.labs2.size() >= 1) {
    		//System.out.println("hasLabel");
    		this.labelCodegen(output, jvmLabel2, label2, labs2);
    	} else {
    		//System.out.println("no Label");
	        // Need two labels
	        String test = output.createLabel();
	        String out = output.createLabel();
	
	        // Branch out of the loop on the test condition
	        // being false
	        output.addLabel(test);
	        condition.codegen(output, out, false);
	
	        // Codegen body
	        if (body instanceof JBlock){
	        	JBlock body2 = (JBlock) body;
	        	for (JStatement statement : body2.statements()) {
	        		if (statement instanceof JBreakStatement) {
	        			output.addBranchInstruction(GOTO, out);
	        		} else {
	        			statement.codegen(output);
	        		}
	            }
	        } else {
	        	if (body instanceof JBreakStatement) {
	        		output.addBranchInstruction(GOTO, out);
	        	} else {
	        		body.codegen(output);
	        	}
	        }
	        
	        //body.codegen(output);
	
	        // Unconditional jump back up to test
	        output.addBranchInstruction(GOTO, test);
	
	        // The label below and outside the loop
	        output.addLabel(out);
    	}
    }
    
    //codegen for use of labels for breaks
    public void labelCodegen(CLEmitter output, String jvmLabel, String label, ArrayList<JLabel> labs) {
    	this.jvmLabel2 = jvmLabel;
    	this.label2 = label; 
    	this.labs2 = labs;
    	this.hasLabel = true;
    	//System.out.println("in codegen");
    	
    	// Need two labels
        String test = output.createLabel();
        String out = output.createLabel();

        // Branch out of the loop on the test condition
        // being false
        output.addLabel(test);
        condition.codegen(output, out, false);

        // Codegen body
        if (body instanceof JBlock){
        	//System.out.println("Iniside body");
        	JBlock body2 = (JBlock) body;
        	for (JStatement statement : body2.statements()) {
        		if (statement instanceof JBreakStatement) {
        			//System.out.println("Is a break");
        			JBreakStatement state = (JBreakStatement) statement;
        			if (!state.hasLabel()) {
        				//System.out.println("out");
        				output.addBranchInstruction(GOTO, out);
        			} else {
        				//System.out.println(labs.get(0));
        				if (labs.size() == 1) {
        					//System.out.println("yes");
        					output.addBranchInstruction(GOTO, labs.get(0).getJVMLabel());
        				} else { //there is more than one label
        					//System.out.println(state.getLabel());
        					for (JLabel foo : labs) {
//        						System.out.println("state " + state.getLabel());
//        						System.out.println("foo " + foo.getLabel());
        						if (state.getLabel().equals(foo.getLabel())) {
        							//System.out.println("in if foo " + foo.getLabel());
        							output.addBranchInstruction(GOTO, foo.getJVMLabel());
        						}
        					}
        				}
        			}
        		} else {
        			//System.out.println(statement);
        			statement.codegen(output);
        		}
            }
        } else {
        	if (body instanceof JBreakStatement) {
        		output.addBranchInstruction(GOTO, out);
        	} else {
        		body.codegen(output);
        	}
        }
        
        //body.codegen(output);

        // Unconditional jump back up to test
        output.addBranchInstruction(GOTO, test);

        // The label below and outside the loop
        output.addLabel(out);
    }

    /**
     * @inheritDoc
     */

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JWhileStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<TestExpression>\n");
        p.indentRight();
        condition.writeToStdOut(p);
        p.indentLeft();
        p.printf("</TestExpression>\n");
        p.printf("<Body>\n");
        p.indentRight();
        body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Body>\n");
        p.indentLeft();
        p.printf("</JWhileStatement>\n");
    }

}
