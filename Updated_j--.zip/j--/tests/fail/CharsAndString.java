package fail;

public class CharsAndString {
	//All escaped chars in strings, in chars
	'\b'
	'\t' '\n' '\f' '\r' '\"' 
	'\'' 
	'\\' 
	
	"\b \t \n \f \r \" \' \\ "
	
	'\p'
	
	"\p"
}