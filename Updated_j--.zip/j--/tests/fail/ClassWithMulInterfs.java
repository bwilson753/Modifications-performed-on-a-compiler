package fail;

public class ClassWithMulInterfs implements ga, sna, buh{
	int i = 0;
	
	public void foo();
	
}jdfljadl//keep compiler happy