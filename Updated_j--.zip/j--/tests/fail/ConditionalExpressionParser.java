package fail;

public class ConditionalExpressionParser {
	public static void main(String[] args){
		int a = true ? 1 : 2;
		int b = (1 > 2) ? 3 : 4;
	}
	dlfjljdlf//for the compiler
}