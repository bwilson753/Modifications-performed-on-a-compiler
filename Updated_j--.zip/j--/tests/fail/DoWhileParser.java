package fail;

public class DoWhileParser {
	public static void main(String[] args){
		int dw = 1;
        do {
            System.out.println("pow");
            dw++;
        } while (3 > dw);
	}
	
}adhkfdj