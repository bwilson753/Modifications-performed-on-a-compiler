package fail;

import java.util.ArrayList;

public class ForParser {
	public static void main(String[] args){
		int i, j, k;
		for (i = 0 , j = 0, k = 0; 1 > i; i--, j--, k--) {
			for (int i = 0; 3 > i; i--) {
			    System.out.println("foo");
			}
		}
		while (true ) {
			
			
		}
		for (; ; ) {
		    System.out.println("foo");
		}
//		//ArrayList<String> sna = new ArrayList<String>();
		for(String buh: sna) {
			System.out.println("foo");
		}
//		for (j = 0;        //<<<<<LINE 21 ******************
//				;) {
//		
//		}
		for (i = 0, j = 0;;i--, j--) {
			
		}
//		
		for(final String buh: sna) {
			System.out.println("foo");
		}
	}
}hk