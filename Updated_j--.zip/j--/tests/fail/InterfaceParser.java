package fail;

public interface InterfaceParser {
	
	final int i = 0;
	
	public void foo();
	
	
	
}jdfljadl//keep compiler happy