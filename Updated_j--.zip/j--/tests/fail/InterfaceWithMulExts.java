package fail;

public interface InterfaceWithMulExts extends ga , sna, buh{
	public void foo();
	
}jdfljadl//keep compiler happy