package fail;

public class Keywords {
	abstract const finally int public this
	boolean continue float interface return throw
	break default for long short throws
	byte do goto native static transient
	case double if new strictfp try
	catch else implements package super void
	char extends import private switch volatile
	class final instanceof protected synchronized while
}