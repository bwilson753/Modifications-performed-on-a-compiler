package fail;

///*The following tests to see if literals values are
// * scanned but then thrown an error message.
// */
public class Literals {
	
	//body commented out so that build output is not so long
	public static void main(String[] args){
		int ai = 
				5;
		double 
		a = 5.0;//1
		double b = .124598;//2
		float bf = .12837f;//tests for float starting with a decimal
//		double c = 3.14e;//should skip
		double d = 3.14e-6;//3
		float e = 3.14f;//4
		float f = 3.14F;//5
		double g = 3.14d;//6
		double h = 3.14D;//7
		float i = 3.14e-6f;//8
		double j = 3.14e+653d;//9
		double k = 3.14e-628;//10
//		int l = 27;//should be fine
//		int m = 0;//should be fine
//		int n = 05;//11 (octal 1)
//		int o = 0000408;//12 (octal 2)
//		int p = 0x25;//13 (octal 3, hex 1)
//		int q = 000x25;//(octal, then identifier)
//		int r = 0x00034;//(octal 5, hex 2)
//		int s = 0981;//(octal 6, error octal)
//		
//		long ll = 27l;//should be fine
//		//long ml = 0;//should be fine
//		long nl = 05L;//11 (octal 1)
//		long ol = 0000408l;//12 (octal 2)
//		long pl = 0x25L;//13 (octal 3, hex 1)
//		long ql = 000x25l;//(reads octal, then identifier)
//		long rl = 0x0Ab3fL;//(octal 5, hex 2)
//		long sl = 0981L;//(octal 6, error octal)
//		long sli = 0981L123;//(triggers an error then reads an int literal)
//		
//		long ml = 0l;//should be fine*SPECIAL CASE
//		
		float lf = 27f;//should be fine
//		//long ml = 0;//should be fine
		float nf = 05F;//11 (octal 1)
		float of = 0000408f;//12 (octal 2)
		float pf = 0x25F;//13 (octal 3, hex 1)
		//float qf = 000x25f;//(interprets int, then hex)
		float rf = 0x0Ab3ff;//(octal 5, hex 2)
//		float sf = 0981F;//(octal 6, error octal)
//		float sfi = 0981F456;//(octal error, then reads integer
//		
//		float sbf = 0771F;//(octal 6, error octal)
		float mf = 0f;//should be fine*SPECIAL CASE
//		
		float tf = 0xc5.1D3f;
		float scf = 0.12e-3f;
		double sd = 0.12e+3;
//		
		double td = 123e-5d;
		float uf = 234e3f;
		double ud = 123e+5;
//		
//		float vf = 123p5;//it sould throw an error because p is used without hex
//		double vdf = 12.3p+5;//it sould throw an error because p is used without hex
		float wf = 0x456p2F;
		float vd = 0x789p-3;
		
		float wf = 0x45.6p2F;
		float vd = 0x78.9p-3;
				
        double ud = 314e2;
        double vd = 567D;
	}
}jfld