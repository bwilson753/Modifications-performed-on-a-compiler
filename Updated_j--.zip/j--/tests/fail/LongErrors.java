package fail;

public class LongErrors {
	public static void main(String[] args) {
		int a = 1L + 1;
		int b = 1 + 1L;
		int c = 1L - 1;
		long d = 1 - 1L;
		long e = 1l * 1;
		int f = 1 * 1l;
	}
}