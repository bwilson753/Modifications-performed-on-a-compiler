package fail;

public class LongParser {
	long a = 34L;
	long b = 8l;
	int c = 5;
	long d = (long) c;
	dflksjd || //makes the compiler happy
}