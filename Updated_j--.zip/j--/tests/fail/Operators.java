package fail;

public class Operators {
			? = == ! ~ != / /= + += ++ -
			-= -- * *= % %= >> >>= >>> >>>= >= >
			<< <<= <= < ^ ^= | |= || & &= &&
}