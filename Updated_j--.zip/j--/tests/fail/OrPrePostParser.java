package fail;

public class OrPrePostParser {
	public static void main(String[] args){
		boolean a = true || false;
		int b = 3;
		b++;
		b--;
		--b;
		++b;
	}
	jkldfj//make compiler happy
}