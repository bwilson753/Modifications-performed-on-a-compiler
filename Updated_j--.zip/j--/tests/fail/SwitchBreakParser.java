package fail;

public class SwitchBreakParser {
	public static void main(String[] args){
		//note that parser does not currently support labels
		//test:
		for (int i = 0; 4 > i; i++){
			break test;
		}
		
		for (int i = 0; 4 > i; i++){
			break;
		}

		int month = 8;
		  int day = 0;
		        String monthString;
		        switch (month) {
//		        case 1: monthString = "January";
//		        	break;
//		        case 2:
//		        default :
		            case 1:  monthString = "January";
		                     break;
		            case 2:  monthString = "February";
		                     break;
		            case 3:  monthString = "March";
		                     break;
		            case 4:  monthString = "April";
		                     break;
		            case 5:  monthString = "May";
		                     break;
		            case 6:  monthString = "June";
		                     switch (day) {
		                     case 1: monthString = "foo";
		                     break;
		                     case 2: monthString = "bar";
		                     break;
		                     default : monthString = "next";
		                     }
		            case 7:  monthString = "July";
		                     break;
		            case 8:  monthString = "August";
		                     break;
		            case 9:  monthString = "September";
		            case 10: monthString = "October";
		      case 11: monthString = "November";
		      case 12: monthString = "December";
		      default: monthString = "Invalid month";
		  }
		  //System.out.println(monthString);
	}
}jmkl