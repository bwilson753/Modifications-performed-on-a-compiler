package fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

//I should have called it throws interface
public interface TryInterface {
	public void test() throws IOException, IndexOutOfBoundsException {
    }
	public int test2() throws IOException, IndexOutOfBoundsException {
    }
}hdfka