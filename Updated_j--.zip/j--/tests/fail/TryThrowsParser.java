package fail;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryThrowsParser {
	public TryThrowsParser() throws IOException, IndexOutOfBoundsException {
		
	}
	 public void test1() throws IOException, IndexOutOfBoundsException {
		 if(true){
			 throw new IOException("foo");
		 }
	 }
	 public int test2() throws IOException, IndexOutOfBoundsException {
	 }
	public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("foo"));
            		br.readLine();
        } catch (IndexOutOfBoundsException e) {
            System.err.println("IndexOutOfBoundsException: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Caught IOException: " + e.getMessage());
        } finally {
            System.out.println("sna");
        }
		 try {
		    //ERROR: without catch or finally 
		 }
    }
}dhfkahj