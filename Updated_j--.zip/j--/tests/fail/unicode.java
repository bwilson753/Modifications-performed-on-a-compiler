package fail;

public class unicode {
	String a = "Here's unicode \u0019  !!!";
	Character b = '\u0123';
	String c = "Here's unicode \u4567";
	String d = "\u89ab  !!!";
	String d = "\ucdef";
	Character e = '\uABCD';
	Character f = '\uEF12';
	Character g = '\uG451';//error
	Character h = '\u34';//error
}
