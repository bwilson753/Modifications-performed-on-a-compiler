package junit;

import junit.framework.TestCase;

import pass.IntBitwise;

public class IntBitwiseTest extends TestCase {
	private IntBitwise intB;
	
	protected void setUp() throws Exception {
		super.setUp();
		intB = new IntBitwise();
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	public void testIntBitwise () {
	this.assertEquals(intB.andBitwise(60, 13) , 12);
	this.assertEquals(intB.orBitwise(60 , 13), 61);
	this.assertEquals(intB.xorBitwise(60 , 13), 49);
	}
}