package pass;

import java.lang.System;
import java.util.ArrayList;
import java.lang.Character;
import java.lang.Long;

public class Casts {
	public static void main(String[] args) {
		int a = (int) 5L;
		long b = (long) 5;
		char c = (char) 97L;
		long d = (long) 'a';
		Character e = (Character) 'a';
		char f = (char) e;
		Long g = (Long) 5L;
		long h = (long) g;
		long i = (long) a + b;
		//ArrayList<Character> f;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(f);
		System.out.println(h);
		System.out.println(i);
	}
}