package pass;

import java.lang.System;

public class ConditionalExpression {
	public static void main(String[] args){
		int a = true ? 1 : 2;
		int b = (1 > 2) ? 3 : 4;
		Object c = true ?  null : null;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
	}
}