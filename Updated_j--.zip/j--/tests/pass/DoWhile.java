package pass;

import java.lang.System;

public class DoWhile {
	public static void main(String[] args){
		int a = 9;
		
		do {
			a--;
		}while (a > 5);
		
		System.out.println(a);
	}
}