package pass;

import java.lang.System;

public class For {
 public static void main (String[] args){
  System.out.println("print");
  int i = 0;
  for (i = 6; i > 3; i--) {
   System.out.println(i);
  }
  
  for (int j = 6; 
    j > 3; 
    j--) {
   System.out.println(i);
  }
  
  for (int k = 0; 3 > k;){
  	System.out.println("one");
  	break;
  	System.out.println("two");
  	k = k + 1;
  }
  
    for(; i > 2;){
   System.out.println("just once");
   i--;
  }
    
    int k = 0;
    while (3 > k) {
    	System.out.println("one");
    	break;
    	System.out.println("two");
    	k = k + 1;
    }
    
    int m = 0;
    
    while (3 > m)
    	break;
    
    while (3 > m)
    	System.out.println(++m);
    
    for (int k = 0; 3 > k;)
    	break;
    
    for (int k = 0; 3 > k;)
    	System.out.println(++k);
    
  
//    for(;;){
//    }
//    
//    for(;;) //causes infinity
//        System.out.println("just once");
 }
}