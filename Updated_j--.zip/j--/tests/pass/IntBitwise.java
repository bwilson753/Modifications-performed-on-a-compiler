package pass;

public class IntBitwise {
	public int andBitwise(int x, int y){
		return x & y;
	}
	public int orBitwise(int x, int y){
		return x | y;
	}
	public int xorBitwise(int x, int y){
		return x ^ y;
	}
} 