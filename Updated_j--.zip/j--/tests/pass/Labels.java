package pass;

import java.lang.System;

public class Labels {
	public static void main(String[] args){
		int a = 9;
		test:
		while (a > 5) {
			a--;
			while (a > 5) {
				System.out.println("inside inner loop");
				break test;
			}
		}
		
		System.out.println(a);
		
		test2:
			while (a > 5) {
				a--;
				test3:
				while (a > 5) {
					System.out.println("inside inner loop");
					break test2;
				}
			}
		System.out.println(a);

	}
}