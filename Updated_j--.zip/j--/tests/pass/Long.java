package pass;

import java.lang.System;

public class Long {
	public static void main(String[] args){
		int a = 32768;
		long b = 2L;
		System.out.println(a);
		System.out.println(b);
		System.out.println(1L);
		System.out.println(127l);//last letter is L
		System.out.println(32767L);
		System.out.println(2147483647l);//last letter is L
		System.out.println(9223372036854775807L);
		
		System.out.println(2L + 3L);
		System.out.println(3L - 2L);
		
		long ab = 0L;
		int ai = 32769;
		ai = (int) ab;
		char d = (char) ai;
		ai = (int) d;
		ab = 3L - 2L;
		long c = (long) ai;
		System.out.println(c);
		ai = (int) c;
		System.out.println(c);
		System.out.println(ab);
		long[] e = {63L};//must use this format
        //e[0] = 63L;
        System.out.println(e[0]);
        long[] e2 = new long[3];
        e2[0] = 63l;//lower case l
        System.out.println(e2[0]);
        int[] ei = new int[3];//must use this format
        ei[0] = 63;
        System.out.println(ei[0]);
		int h = 3;
		long ef = 5L;
		int i = 6;
		long f = 4L;
		long hep = ef * f;
		System.out.println(hep);
		long j = ef - f;
		System.out.println(j);
		long g = ef + f;
		System.out.println(g);
		
		long k = 1L;
		k += 1L;
		System.out.println(k);
		
		int eij = 5;
		int fi = 4;
		int gi = eij + fi;
		System.out.println(gi);
        
		Long l = new Long();
		System.out.println(l.get2());
		System.out.println(l.get());
		
		Long2 l2 = new Long2();
		System.out.println(l2.getLong());
		
		int mi = 3;
		long mL = 3L;
		int n = mi + (int) mL;
		System.out.println(n);
		long o = (long) mi - mL;
		System.out.println(o);
		int p = (int) mL * mi;
		System.out.println(p);
	}
	long tester = 3L;
	int tester2 = 3;
	 public int get2() {
		 return tester2;
	 }
	 
	 public long get() {
	     return tester;
	 }
}

class Long2 {
	long test3 = 5L;
	
	public long getLong(){
		return this.test3;
	}
}
