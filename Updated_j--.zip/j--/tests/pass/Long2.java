package pass;

import java.lang.System;

public class Long2 {
	public static void main(String[] args){
		long[] e = {63L};//must use this format
        //e[0] = 63L;
        System.out.println(e[0]);
        long[] e2 = new long[3];
        e2[0] = 63l;//lower case l
        System.out.println(e2[0]);
        ++e[0];
        e[0] += 1L;
        System.out.println(e[0]);
        e[0]--;
        System.out.println(e[0]);
        Long2 l = new Long2();
        ++l.tester2;
        ++l.tester;
        System.out.println(l.tester);
        l.tester--;
        System.out.println(l.tester);
        l.tester += 2L;
        System.out.println(l.tester);
        
        Long3 l2 = new Long3();
        ++l2.test3;
        l2.test3--;
        l2.test3 += 2L;
        System.out.println(l2.test3);
    	 
	}
	long tester = 3L;
	int tester2 = 3;
	public int get2() {
		 return tester2;
	 }
	 
	 public long get() {
	     return tester;
	 }
	
}

class Long3 {
	long test3 = 5L;
	
	public long getLong(){
		return this.test3;
	}
}