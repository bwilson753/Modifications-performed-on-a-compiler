package pass;
public class Modulo {
	public int mod ( int x, int y) {
		return x % y;
	}
}