package pass;

public class MultiComments {
	
	public static void main (String[] args) {
		/*this just tests for comments and does nothing else
		 * 
		 */
		
	}
}