package pass;

import java.lang.System;

public class Or {
	public static void main (String[] args) {
		if (true || false) {
			System.out.println("You got it 1!");
		}
		if (false || true) {
			System.out.println("You got it 2!");
		}
		if (false || false) {
			System.out.println("You didn't get it!");
		} else {
			System.out.println("You got it 3!");
		}
		if (true || true){
			System.out.println("You got it 4!");
		}
		
		boolean a = true || false;
		System.out.println(a);
		
		int b = 7;
		
		do {
			System.out.println("inside 1st do");
			b--;
		} while (b > 5 || b > 5);
		
		do {
			System.out.println("inside 2nd do");
			b--;
		} while (b > 3 || b > 5);//true false
		
		do {
			System.out.println("inside 3rd do");
			b--;
		} while (b > 3 || b > 1);//false true
	}
}