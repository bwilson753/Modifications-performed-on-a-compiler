package pass;

import java.lang.System;

public class Switch {
	public static void main(String[] args) {
		System.out.println("test");
		//modification from book page 196
		int a = 5;
		
		int d = 99;
		switch (d) {
			case 0:
				d--;
			case 3:
				d--;
			default :
				d--;
		}
		
		int c = 1;
		switch (c) {
			case 0: 
				a--;
				break;
			case 1: 
				a--;
				break;
			case 2: 
				a--;
				break;
			default : 
				a--;
		}
		System.out.println(a);
		
		char h = 'h';
		switch (h) {
			case 'q':
				break;
				d--;
			case 'z':
				d--;
			default :
				d--;
		}
		System.out.println(h);
		
		//j-- does not appear to currently support a mix
		//of chars or ints.
//		char p = 'p';
//		switch (p) {
//			case 'p':
//				d--;
//			case 4:
//				d--;
//			default :
//				d--;
//		}
//		System.out.println(h);

	} 
}