package pass;

public class UnaryPlus {
	public int unaryPlus(int x){
		//return -x;//test
		return +x;
	}
}